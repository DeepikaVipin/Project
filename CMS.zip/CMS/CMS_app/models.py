from django.db import models
from datetime import datetime

# Create your models here.
class Staff(models.Model):

    name = models.CharField(max_length=30)
    email = models.CharField(max_length=40,unique=True)
    password = models.CharField(max_length=50)
    address = models.CharField(max_length=30)
    gender = models.CharField(max_length=5)
    ph_no = models.IntegerField()
    dbs_no = models.CharField(max_length=30)
    nin_no = models.CharField(max_length=30)
    dob =  models.DateField()
    staff_type =  models.CharField(max_length=30)
    image =  models.ImageField(upload_to='Staff/', height_field=None, width_field=None, max_length=100)



class Resident(models.Model):
    name = models.CharField(max_length=30)
    email = models.CharField(max_length=40,unique=True)
    address = models.CharField(max_length=30)
    gender = models.CharField(max_length=5)
    ph_no = models.IntegerField()
    dob =  models.DateField()
    importent_to_me =  models.CharField(max_length=30, null=True, blank=True)
    image =  models.ImageField(upload_to='Resident/', height_field=None, width_field=None, max_length=100)
    like_to_talk=models.CharField(max_length=300, null=True, blank=True)
    things_that_upset=models.CharField(max_length=300, null=True, blank=True)
    communication=models.CharField(max_length=300, null=True, blank=True)
    mobility=models.CharField(max_length=300, null=True, blank=True)
    like_in_me=models.CharField(max_length=300, null=True, blank=True)
    hobbies=models.CharField(max_length=300, null=True, blank=True)
    important_people_and_place=models.CharField(max_length=300, null=True, blank=True)
    childhood_memories=models.CharField(max_length=300, null=True, blank=True)
    working_life=models.CharField(max_length=300, null=True, blank=True)
    medical_history=models.CharField(max_length=300, null=True, blank=True)


class Activity(models.Model):
    res_id=models.IntegerField()
    activity=models.CharField(max_length=30)
    note = models.CharField(max_length=300)
    staff = models.CharField(max_length=40)
    date_time =models.DateTimeField(default=datetime.now(), blank=None, null=None)


class Shift(models.Model):
    staff = models.CharField(max_length=40,unique=True)
    mon=models.CharField(max_length=30,null=True, blank=True,default=None)
    tue=models.CharField(max_length=30,null=True, blank=True,default=None)
    wed=models.CharField(max_length=30,null=True, blank=True,default=None)
    thu=models.CharField(max_length=30,null=True, blank=True,default=None)
    fri=models.CharField(max_length=30,null=True, blank=True,default=None)
    sat=models.CharField(max_length=30,null=True, blank=True,default=None)
    sun=models.CharField(max_length=30,null=True, blank=True,default=None)


class Leave(models.Model):
    staff = models.CharField(max_length=40)
    application_date =models.DateTimeField(default=datetime.now(), blank=None, null=None)
    date=models.DateField(null=True, blank=True,default=None)
    days=models.IntegerField(null=True, blank=True,default=None)
    reason=models.CharField(max_length=30,null=True, blank=True,default=None)
    admin_permission=models.IntegerField(null=True, blank=True,default=None)
    date_time =models.DateTimeField(null=True, blank=True,default=None)
    cancle=models.IntegerField(null=True, blank=True,default=None)


class ShiftChange(models.Model):
    staff = models.CharField(max_length=40)
    application_date =models.DateTimeField(default=datetime.now(), blank=None, null=None)
    shift=models.CharField(max_length=30,null=True, blank=True,default=None)
    changed_shift=models.CharField(max_length=30,null=True, blank=True,default=None)
    date_time =models.DateTimeField(null=True, blank=True,default=None)
    date=models.DateField(null=True, blank=True,default=None)
    reason=models.CharField(max_length=30,null=True, blank=True,default=None)
    admin_permission=models.IntegerField(null=True, blank=True,default=None)
    cancle=models.IntegerField(null=True, blank=True,default=None)

   
