from django.shortcuts import render
from django.db import IntegrityError
from django.http import HttpResponse
from django.shortcuts import render
import json
from django.http import JsonResponse
from django.template.loader import get_template
from django.template import Context, Template
from django.contrib.auth import authenticate, login,logout
from django.shortcuts import redirect
from CMS_app.models import Staff,Resident,Activity,Shift,Leave,ShiftChange
from django.contrib.auth.models import User
from django import db
from django.utils.timezone import datetime 
from datetime import date
import base64
from django.core.files.base import ContentFile
import os
import time as t
import pandas as pd
from datetime import timedelta
from copy import copy


# Create your views here.
def admin_login(request):
    content={}
    if request.method == 'POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
             if user.is_superuser:
                login(request, user)
            # messages.info(request, f"You are now logged in as {username}")
                return redirect('/admin_dashboard')
                print("sucess")
             else:
              return render(request,'admin_login.html',content)  
        else:
            # messages.error(request, "Invalid username or password.")
            # content['err']=True
            # content['msg']="Invalid username or password"
            content={'err':True,'msg': "Invalid username or password"}
            print(" notsucess")
    return render(request,'admin_login.html',content)

def staff_login(request):
    content={}
    if request.method == 'POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user =  authenticate(username=username, password=password)
        if user is not None:
            if user.is_staff:
                login(request, user)
                print("sucess")
            # messages.info(request, f"You are now logged in as {username}")
                return redirect('/staff_dashboard')
            else:
              return render(request,'staff_login.html',content)  
             
        else:
            # messages.error(request, "Invalid username or password.")
            # content['err']=True
            # content['msg']="Invalid username or password"
            content={'err':True,'msg': "Invalid username or password"}
            print(" notsucess")
    return render(request,'staff_login.html',content)

def admin_dashboard(request):
    if request.user.is_authenticated:
        staff_da=Staff.objects.all().values()
        staff = len(staff_da)
        today = date.today()
        day={"Monday":"mon","Tuesday":"tue","Wednesday":"wed","Thursday":"thu","Friday":"fri","Saturday":"sat","Sunday":"sun"}
        d = pd.Timestamp(today)
        days=day[d.day_name()]  
        res = len(Resident.objects.all().values())
 
        staff_d1=[]
 
        for d in staff_da:
            try:
                sta=Shift.objects.filter(staff=d['email']).values()
                a=copy(d)
                a['shift']=sta[0][days]
                try:
                    leave_dates=[]
                    l=Leave.objects.filter(staff=d['email'],admin_permission=1).values()
                    for le in l:
                        date_1 = datetime.strptime(str(le['date']), "%Y-%m-%d")
                        for n in range(le['days']):
                            leave_dates.append(str(date_1 + timedelta(days=(n))))
                 
                    if  str(datetime.strptime(str(today), "%Y-%m-%d")) in leave_dates:
                        a['special']=True
                        a['action']="Leave"
                        staff_d1.append(a)
                  
                      
                    else:
                        a['special']=False
                        a['action']="Leave"
                        staff_d1.append(a)
                        
                            
                except Leave.DoesNotExist:
                    print("no leave")
                    a['special']=False
           
                    staff_d1.append(a)
            except Shift.DoesNotExist:
                print("shift not assigned")
 
        for g in staff_da:
            try:
                sta=Shift.objects.filter(staff=g['email']).values()
                b=copy(g)
                b['shift']=sta[0][days]
                
                try:
                    s=ShiftChange.objects.filter(staff=g['email'],date=today,admin_permission=1).values()
                    for se in s:
                        b['special']=True
                        b['action']="Shift Change"
                        b['changed_shift']=se['changed_shift']
                        staff_d1.append(b)
                    
                     
                except ShiftChange.DoesNotExist: 
                    print("no shiftchange") 
                    b['special']=False
                    staff_d1.append(b)
        
            except Shift.DoesNotExist:
                print("shift not assigned")

        return render(request,'admin_dashboard.html',{"user_name":request.user.username,"res":res,"staff":staff,"staff_d":staff_d1,"rdata":GetNotification()})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/admin_login')

def staff_dashboard(request):
    if request.user.is_authenticated:
        leaveandshiftchane=[]
        today = date.today()
        activity = Activity.objects.filter(staff=request.user.username,date_time__year=today.year, date_time__month=today.month, date_time__day=today.day).values()
        leave = Leave.objects.filter(staff=request.user.username).values()
        shiftchange = ShiftChange.objects.filter(staff=request.user.username).values()
        # Leave.objects.filter(staff=request.user.username).update(date_time=datetime.now())
        for data in activity:
            res_name=Resident.objects.filter(id=data['res_id']).values()
            
            data['name']=res_name[0]['name']

        for l in leave:
            date_1 = datetime.strptime(str(l['date']), "%Y-%m-%d")
            l["end_date"] = date_1 + timedelta(days=(l['days']-1))
            l["action"] = "leave"
            if (datetime.strptime(str(today), "%Y-%m-%d") - l["end_date"]).days <= 0:
                leaveandshiftchane.append(l)
        for s in shiftchange:
            if (datetime.strptime(str(today), "%Y-%m-%d") - datetime.strptime(str(s['date']), "%Y-%m-%d")).days <= 0:
                s["action"] = "shiftchange"
                leaveandshiftchane.append(s)
        
        staff=Staff.objects.filter(email=request.user.username).values()
        return render(request,'staff_dashboard.html',{"user_name":request.user.username,"profile":staff[0]['image'],"name":staff[0]['name'],"activity":activity,"leaveandshiftchange":leaveandshiftchane})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/')

def admin_staff(request):
    if request.user.is_authenticated:
        return render(request,'admin_staff.html',{"user_name":request.user.username,"rdata":GetNotification()})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/admin_login')


def ShowNotifications(request):
    if request.user.is_authenticated:
        return render(request,'ShowNotifications.html',{"user_name":request.user.username,"rdata":GetNotification()})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/admin_login')

def admin_res(request):
    if request.user.is_authenticated:
        return render(request,'admin_res.html',{"user_name":request.user.username,"rdata":GetNotification()})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/admin_login')

def staff_res(request):
    if request.user.is_authenticated:
        staff=Staff.objects.filter(email=request.user.username).values()
        return render(request,'staff_res.html',{"user_name":request.user.username,"profile":staff[0]['image'],"name":staff[0]['name']})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/')

def LaS(request):
    if request.user.is_authenticated:
        staff=Staff.objects.filter(email=request.user.username).values()
        return render(request,'LaS.html',{"user_name":request.user.username,"profile":staff[0]['image'],"name":staff[0]['name']})
    else:
        content={'err':True,'msg': "Please Login First"}
        return redirect('/')

def NewStaff(request):
    if request.method == 'POST':
        return render(request,'NewStaff.html')

def StaffActivity(request):
    if request.user.is_authenticated:
        today = date.today()
        staff=Staff.objects.filter(email=request.user.username).values()
        return render(request,'StaffActivity.html',{'date':str(today),"user_name":request.user.username,"profile":staff[0]['image'],"name":staff[0]['name']})

def NewRes(request):
    if request.method == 'POST':
        return render(request,'NewRes.html')

def AddNewStaff(request):
    if request.method == 'POST':
        name=request.POST.get('name')
        # sur_name = request.POST.get('sur_name')
        address = request.POST.get('address')
        ph_no = request.POST.get('ph_no')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        dbs_no = request.POST.get('dbs_no')
        nin_no = request.POST.get('nin_no')
        staff_type = request.POST.get('staff_type')
        dob = request.POST.get('dob')
        try:
            adduser = User.objects.create_user(username = email,email = email,password = 'CMS',is_staff=True)
            adduser.save()
            newStaff = Staff.objects.create(name = name,address=address,ph_no=ph_no,email=email,gender=gender,dbs_no=dbs_no,nin_no=nin_no,staff_type=staff_type,dob=dob)
            newStaff.save()
            
            return JsonResponse({'data':'111'})
        except IntegrityError:
            return JsonResponse({'data':'110'})
     
        except Exception as e:
            print(e)
            return JsonResponse({'data':'error'})
    return JsonResponse({'data':'error'})

 
      

def AddNewRes(request):
    if request.method == 'POST':
        name=request.POST.get('name')
        address = request.POST.get('address')
        ph_no = request.POST.get('ph_no')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        importent_to_me=request.POST.get('importent_to_me')
        like_to_talk=request.POST.get('like_to_talk')
        things_that_upset=request.POST.get('things_that_upset')
        communication=request.POST.get('communication')
        mobility=request.POST.get('mobility')
        like_in_me=request.POST.get('like_in_me')
        hobbies=request.POST.get('hobbies')
        important_people_and_place=request.POST.get('important_people_and_place')
        childhood_memories=request.POST.get('childhood_memories')
        working_life=request.POST.get('working_life')
        medical_history=request.POST.get('medical_history')
        try:
            newRes = Resident.objects.create(medical_history=medical_history,working_life=working_life,childhood_memories=childhood_memories,important_people_and_place=important_people_and_place,name = name,address=address,ph_no=ph_no,email=email,gender=gender,dob=dob,importent_to_me=importent_to_me,like_to_talk=like_to_talk,things_that_upset=things_that_upset,communication=communication,mobility=mobility,like_in_me=like_in_me,hobbies=hobbies)
        
            newRes.save()
            return JsonResponse({'data':'111'})
        except IntegrityError:
            return JsonResponse({'data':'110'})
     
        except Exception as e:
                print(e)
                return JsonResponse({'data':'error'})
    return JsonResponse({'data':'error'})

    
      

def GetStaffActivity(request):
    if request.method == 'POST':
        date= request.POST.get('date')
        data = Activity.objects.filter(staff=request.user.username,date_time__date=date).values()
        template = get_template('GetStaffActivity.html')
        for d in data:
            res=Resident.objects.filter(id=d['res_id']).values()
            d['name']=res[0]['name']
            d['image']=res[0]['image']
        context = {
            'data': data,
        }
        return HttpResponse(template.render(context, request))


def GetStaffActivityAdmin(request):
    if request.method == 'POST':
        date= request.POST.get('date')
        user=request.POST.get('user')
        data = Activity.objects.filter(staff=user,date_time__date=date).values()
        template = get_template('GetStaffActivity.html')
        for d in data:
            res=Resident.objects.filter(id=d['res_id']).values()
            d['name']=res[0]['name']
            d['image']=res[0]['image']
        context = {
            'data': data,
        }
        return HttpResponse(template.render(context, request))

def GetResActivityAdmin(request):
    if request.method == 'POST':
        date= request.POST.get('date')
        id=request.POST.get('id')
        data = Activity.objects.filter(res_id=id,date_time__date=date).values()
        template = get_template('GetResActivityAdmin.html')
        for d in data:
            res=Staff.objects.filter(email=d['staff']).values()
            d['name']=res[0]['name']
            d['image']=res[0]['image']
        context = {
            'activity': data,
        }
        return HttpResponse(template.render(context, request))

       
def GetAdminStaffs(request):
    if request.method == 'POST':
        mydata = Staff.objects.all().values()
        template = get_template('GetAdminStaffs.html')
        context = {
            'mymembers': mydata,
        }
        return HttpResponse(template.render(context, request))

def GetAdminRes(request):
    if request.method == 'POST':
        mydata = Resident.objects.all().values()
        template = get_template('GetAdminRes.html')
        context = {
            'mymembers': mydata,
        }
        return HttpResponse(template.render(context, request))
        # return render(request,'GetAdminStaffs.html')

def GetStaffRes(request):
    if request.method == 'POST':
        mydata = Resident.objects.all().values()
        template = get_template('GetStaffRes.html')
        context = {
            'mymembers': mydata,
        }
        return HttpResponse(template.render(context, request))


def DeleteStaff(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        instance = Staff.objects.get(id=id)
        user = User.objects.get(username=instance.email)
        try:
            shift = Shift.objects.get(staff=instance.email)
            flag=True
        except Shift.DoesNotExist:
            flag=False
       
      

        try:
            instance.delete()
            user.delete()
            if flag:
                shift.delete()
            return JsonResponse({'data':'111'})
        except:
            return JsonResponse({'data':'error'})



def GetShift(request):
    if request.method == 'POST':
        date=request.POST.get('date')
        day={"Monday":"mon","Tuesday":"tue","Wednesday":"wed","Thursday":"thu","Friday":"fri","Saturday":"sat","Sunday":"sun"}
        d = pd.Timestamp('2022-05-02')
        days=day[d.day_name()]  
        try:
        
            staff = Shift.objects.get(staff=request.user.username)
            
            return JsonResponse({'data':staff.__dict__[days],'err':False})
            
        except Shift.DoesNotExist:
            return JsonResponse({'data':'Please Inform Admin to Assign a Shift','err':True})
 
    else:
        return JsonResponse({'data':'error','err':True})


def UpdateShift(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        print(id)
        monday=request.POST.get('monday')
        tuesday =request.POST.get('tuesday')
        wednesday=request.POST.get('wednesday')
        thursday=request.POST.get('thursday')
        friday=request.POST.get('friday')
        saturday=request.POST.get('saturday')
        sunday=request.POST.get('sunday')

 

        try:
            Shift.objects.update_or_create(staff=id,defaults={'mon':monday,'tue':tuesday,'wed':wednesday,'thu':thursday,'fri':friday,'sat':saturday,'sun':sunday}) 
            return JsonResponse({'data':'111'})
        except:
            return JsonResponse({'data':'error'})
    else:
        return JsonResponse({'data':'error'})

def DeleteRes(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        instance = Resident.objects.get(id=id)
        try:
            instance.delete()
            return JsonResponse({'data':'111'})
        except:
            return JsonResponse({'data':'error'})

def StaffProfile(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        staff = Staff.objects.get(id=id)

        

        try:
             shift = Shift.objects.get(staff=staff.email)
        except Shift.DoesNotExist:
            shift=""

  
        
        data = Activity.objects.filter(staff=staff.email,date_time__date=date.today()).values()
        for d in data:
            res=Resident.objects.filter(id=d['res_id']).values()
            d['name']=res[0]['name']
            d['image']=res[0]['image']

      


        template = get_template('StaffProfile.html')
        context = {
            'staff':staff,
            'dob_str':str(staff.dob),
            'data': data,
            'date_str':str(date.today()),
            'shift':shift
            }
        return HttpResponse(template.render(context, request))

def ResProfile(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        res = Resident.objects.get(id=id)

        


        activity = Activity.objects.filter(res_id=id,date_time__date=date.today()).values()
        for d in activity:
            staff=Staff.objects.filter(email=d['staff']).values()
            d['name']=staff[0]['name']
            d['image']=staff[0]['image']

        # activity = Activity.objects.filter(res_id=id).values()
        # for data in activity:
        #     staff_name=Staff.objects.filter(email=data['staff']).values()
            
        #     data['name']=staff_name[0]['name']


        template = get_template('ResProfile.html')
        context = {
            'res':res,
            'dob_str':str(res.dob),
            'activity':activity,
            'today_date_str':str(date.today())
            }
        return HttpResponse(template.render(context, request))

def ResProfileStaff(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        today = datetime.today()
        activity = Activity.objects.filter(res_id=id,date_time__year=today.year, date_time__month=today.month, date_time__day=today.day).values()
        for data in activity:
            staff_name=Staff.objects.filter(email=data['staff']).values()
            
            data['name']=staff_name[0]['name']
            
        res = Resident.objects.get(id=id)
        staff=Staff.objects.filter(email=request.user.username).values()
        template = get_template('ResProfileStaff.html')
        context = {
            'res':res,
            'username':request.user.username,
            'activity':activity,
            'staff_type':staff[0]['staff_type']
            
            }
        return HttpResponse(template.render(context, request))


def AdminPass(request):
    if request.method == 'POST':
        return render(request,'admin_password.html')

def StaffPass(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            try:
                shift = Shift.objects.get(staff=request.user.username)
            except Shift.DoesNotExist:
                shift=""
            profile = Staff.objects.get(email=request.user.username)
            template = get_template('staff_password.html')
            context = {
                'staff':profile,
                "shift":shift
                
                
                }
            return HttpResponse(template.render(context, request))
        else:
            return redirect('/staff_login')





def ChangeAdminPass(request):
    
    if request.user.is_authenticated:
        uname = request.user.username
        if request.method == 'POST':
            old_password = request.POST.get('cupass')
            new_password = request.POST.get('pass')
            retype_new_password = request.POST.get('pass1')
            user = authenticate(username=uname, password=old_password)
            if user is not None:
                if new_password == retype_new_password and new_password != '':
                    u = User.objects.get(username=uname)
                    u.set_password(new_password)
                    u.save()
                    return JsonResponse({'data':'111'})
                else:
                    return JsonResponse({'data':'110ds'})
            else:
                return JsonResponse({'data':'110'})
    else:
        return redirect('/admin_login')





def AdminLogout(request):
    logout(request)
    return redirect('/admin_login')

def StaffLogout(request):
    logout(request)
    return redirect('/')






def AddActivity(request):
    if request.method == 'POST' and request.user.is_authenticated:

        note=request.POST.get('note')
        res_id = request.POST.get('id')
        activity = request.POST.get('activity')
        staff=request.user.username
        try:
            newAct = Activity.objects.create(res_id=res_id,activity=activity,staff=staff,note=note)
        
            newAct.save()
            return JsonResponse({'data':'111'})
     
        except Exception as e:
                print(e)
                return JsonResponse({'data':'error'})
    else:
        return redirect('/staff_login')



def UpdateResPhoto(request):
    if request.method == 'POST':
        id= request.POST.get('id')
        image= request.POST.get('image')
        format, imgstr = image.split(';base64,')
        ext = format.split('/')[-1]
        file_name = str(t.time())+"." + ext

        data = ContentFile(base64.b64decode(imgstr),name=file_name) 
      
        


        try:
            post = Resident.objects.get(id=id)
            try:
                os.remove(post.image.path)
            except Exception as e:
                print('No image for delete '+str(e))
                

            

            obj = Resident.objects.get(id=id)
            obj.image = data
            obj.save()
            return JsonResponse({'data':'111'})
  
     
            
        except Exception as e:
            print(e)
            return JsonResponse({'data':'error'})


    



def UpdateStaff(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            id= request.POST.get('id')
            name=request.POST.get('name')
            address = request.POST.get('address')
            ph_no = request.POST.get('ph_no')
            gender = request.POST.get('gender')
            dbs_no = request.POST.get('dbs_no')
            nin_no = request.POST.get('nin_no')
            staff_type = request.POST.get('staff_type')
            dob = request.POST.get('dob')
        
            try:
                Staff.objects.filter(id=id).update(name=name,address=address,ph_no=ph_no,gender=gender,dbs_no=dbs_no,nin_no=nin_no,staff_type=staff_type,dob=dob)
                
                return JsonResponse({'data':'111'})
     
            except Exception as e:
                print(e)
                return JsonResponse({'data':'error'})
        else:
            return redirect('/admin_login')




def UpdateRes(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            id= request.POST.get('id')
            name=request.POST.get('name')
            address = request.POST.get('address')
            ph_no = request.POST.get('ph_no')
            gender = request.POST.get('gender')
            dob = request.POST.get('dob')
            importent_to_me=request.POST.get('importent_to_me')
            like_to_talk=request.POST.get('like_to_talk')
            things_that_upset=request.POST.get('things_that_upset')
            communication=request.POST.get('communication')
            mobility=request.POST.get('mobility')
            like_in_me=request.POST.get('like_in_me')
            hobbies=request.POST.get('hobbies')
            important_people_and_place=request.POST.get('important_people_and_place')
            childhood_memories=request.POST.get('childhood_memories')
            working_life=request.POST.get('working_life')
            medical_history=request.POST.get('medical_history')
            print(importent_to_me)
        
            try:
                Resident.objects.filter(id=id).update(medical_history=medical_history,working_life=working_life,childhood_memories=childhood_memories,important_people_and_place=important_people_and_place,name = name,address=address,ph_no=ph_no,gender=gender,dob=dob,importent_to_me=importent_to_me,like_to_talk=like_to_talk,things_that_upset=things_that_upset,communication=communication,mobility=mobility,like_in_me=like_in_me,hobbies=hobbies)
                return JsonResponse({'data':'111'})
     
            except Exception as e:
                print(str(e))
                return JsonResponse({'data':'error'})
        else:
            return redirect('/admin_login')



def UpdateStaffPhoto(request):
    if request.method == 'POST':
        id= request.POST.get('id')
        print(id)
        image= request.POST.get('image')
        format, imgstr = image.split(';base64,')
        ext = format.split('/')[-1]
        file_name = str(t.time())+"." + ext

        data = ContentFile(base64.b64decode(imgstr),name=file_name) 
      
        


        try:
            post = Staff.objects.get(id=id)
            try:
                os.remove(post.image.path)
            except Exception as e:
                print('No image for delete '+str(e))
                

            

            obj = Staff.objects.get(id=id)
            obj.image = data
            obj.save()
            return JsonResponse({'data':'111'})
  
     
            
        except Exception as e:
            print(e)
            return JsonResponse({'data':'error'})





def ApplyLeave(request):
    if request.method == 'POST':
        reason=request.POST.get('reason')
        days=request.POST.get('days')
        date=request.POST.get('date')
      
        try:
            newLeave = Leave.objects.create(staff=request.user.username,date=date,days=days,reason=reason,admin_permission=0)
        
            newLeave.save()
            return JsonResponse({'data':'111'})
        except IntegrityError:
            return JsonResponse({'data':'110'})
     
        except Exception as e:
                print(e)
                return JsonResponse({'data':'error'})
    return JsonResponse({'data':'error'})



def Shiftchange(request):
    if request.method == 'POST':
        reason=request.POST.get('reason')
        shift =request.POST.get('shift')
        shiftchange =request.POST.get('shiftchange')
        date=request.POST.get('date')
      
        try:
            newshiftchange = ShiftChange.objects.create(staff=request.user.username,date=date,shift=shift,changed_shift=shiftchange,reason=reason,admin_permission=0)
        
            newshiftchange.save()
            return JsonResponse({'data':'111'})
        except IntegrityError:
            return JsonResponse({'data':'110'})
     
        except Exception as e:
                print(e)
                return JsonResponse({'data':'error'})
    return JsonResponse({'data':'error'})


def GetNotification():
    rdata=[]
    leave=Leave.objects.filter(admin_permission=0).values()
    shiftchange=ShiftChange.objects.filter(admin_permission=0).values()
    for l in leave:
        staff=Staff.objects.filter(email=l['staff']).values()
        date_1 = datetime.strptime(str(l['date']), "%Y-%m-%d")
        l["end_date"] = date_1 + timedelta(days=(l['days']-1))
        l['name']=staff[0]['name']
        l['action']="Leave"
        rdata.append(l)

    for s in shiftchange:
        staff=Staff.objects.filter(email=s['staff']).values()
        s['name']=staff[0]['name']
        s['action']="Shift Change"
        rdata.append(s)
    print(rdata)
    return rdata



def RejectPer(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        action=request.POST.get('action')


        try:
            if action=="Leave":
                Leave.objects.filter(id=id).update(admin_permission=2,date_time=datetime.now())
                return JsonResponse({'data':'111'})
            if action=="Shift Change":
                ShiftChange.objects.filter(id=id).update(admin_permission=2,date_time=datetime.now())
                return JsonResponse({'data':'111'})
        except:
            return JsonResponse({'data':'error'})
    else:
        return JsonResponse({'data':'error'})




def GrantPer(request):
    if request.method == 'POST':
        id=request.POST.get('id')
        action=request.POST.get('action')
        try:
            if action=="Leave":
                Leave.objects.filter(id=id).update(admin_permission=1,date_time=datetime.now())
                return JsonResponse({'data':'111'})
            if action=="Shift Change":
                ShiftChange.objects.filter(id=id).update(admin_permission=1,date_time=datetime.now())
                return JsonResponse({'data':'111'})
        except:
            return JsonResponse({'data':'error'})
    else:
        return JsonResponse({'data':'error'})