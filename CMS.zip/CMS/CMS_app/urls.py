from . import views
from django.contrib import admin
from django.urls import path,include
from django.conf.urls.static import static
from django.conf import settings



urlpatterns = [
    path('',views.staff_login,name='staff_login'),
    path('admin_login',views.admin_login,name='admin_login'),
    path('admin_dashboard',views.admin_dashboard,name='admin_dashboard'),
    path('staff_dashboard',views.staff_dashboard,name='staff_dashboard'),
    path('admin_staff',views.admin_staff,name='admin_staff'),
    path('admin_res',views.admin_res,name='admin_res'),
    path('staff_res',views.staff_res,name='staff_res'),
    path('NewStaff',views.NewStaff,name='NewStaff'),
    path('NewRes',views.NewRes,name='NewRes'),
    path('AddNewStaff',views.AddNewStaff,name='AddNewStaff'),
    path('AddNewRes',views.AddNewRes,name='AddNewRes'),
    path('GetAdminStaffs',views.GetAdminStaffs,name='GetAdminStaffs'),
    path('GetAdminRes',views.GetAdminRes,name='GetAdminRes'),
    path('GetStaffRes',views.GetStaffRes,name='GetStaffRes'),
    path('DeleteStaff',views.DeleteStaff,name='DeleteStaff'),
    path('DeleteRes',views.DeleteRes,name='DeleteRes'),
    path('StaffProfile',views.StaffProfile,name='StaffProfile'),
    path('ResProfile',views.ResProfile,name='ResProfile'),
    path('ResProfileStaff',views.ResProfileStaff,name='ResProfileStaff'),
    path('AdminPass',views.AdminPass,name='AdminPass'),
    path('StaffPass',views.StaffPass,name='StaffPass'),
    path('ChangeAdminPass',views.ChangeAdminPass,name='ChangeAdminPass'),
    path('AdminLogout',views.AdminLogout,name='AdminLogout'),
    path('StaffLogout',views.StaffLogout,name='StaffLogout'),
    path('AddActivity',views.AddActivity,name='AddActivity'),
    path('StaffActivity',views.StaffActivity,name='StaffActivity'),
    path('GetStaffActivity',views.GetStaffActivity,name='GetStaffActivity'),
    path('GetStaffActivityAdmin',views.GetStaffActivityAdmin,name='GetStaffActivityAdmin'),
    path('GetResActivityAdmin',views.GetResActivityAdmin,name='GetResActivityAdmin'),
    path('UpdateResPhoto',views.UpdateResPhoto,name='UpdateResPhoto'),
    path('UpdateStaffPhoto',views.UpdateStaffPhoto,name='UpdateStaffPhoto'),
    path('UpdateStaff',views.UpdateStaff,name='UpdateStaff'),
    path('UpdateRes',views.UpdateRes,name='UpdateRes'),
    path('UpdateShift',views.UpdateShift,name='UpdateShift'),
    path('LaS',views.LaS,name='Las'),
    path('GetShift',views.GetShift,name='GetShift'),
    path('ApplyLeave',views.ApplyLeave,name='ApplyLeave'),
    path('Shiftchange',views.Shiftchange,name='Shiftchange'),
    path('ShowNotifications',views.ShowNotifications,name='ShowNotifications'),
    path('GrantPer',views.GrantPer,name='GrantPer'),
    path('RejectPer',views.RejectPer,name='RejectPer'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)