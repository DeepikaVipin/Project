function NewStaff() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/NewStaff",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}



function NewRes() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/NewRes",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}



function GetAdminStaffs() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetAdminStaffs",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}


function GetAdminRes() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetAdminRes",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}


function GetStaffRes() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetStaffRes",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}

function StaffProfile(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {
        id
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/StaffProfile",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}



function ResProfile(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {
        id
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/ResProfile",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}

function ResProfileStaff(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var data = {
        id
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/ResProfileStaff",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}

function AdminPass() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();



    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/AdminPass",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}




function StaffPass() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    $(".date_col").html("");


    var data = {

    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/StaffPass",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}



function GetStaffActivity() {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    var date = $(".date").val();


    var data = {
        date
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetStaffActivity",
        type: "POST",
        data: data,
        success: function(data) {
            $('.data').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}




function GetStaffActivityAdmin(user) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    var date = $(".date").val();


    var data = {
        date,
        user
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetStaffActivityAdmin",
        type: "POST",
        data: data,
        success: function(data) {
            $('.activity_table').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}




function GetResActivityAdmin(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    var date = $(".date").val();


    var data = {
        date,
        id
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetResActivityAdmin",
        type: "POST",
        data: data,
        success: function(data) {
            $('.activity_acc').html(data)

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}





function GetShift(e) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();


    var html = ""
    var data = {
        date: e.target.value
    };
    $.ajax({
        headers: { "X-CSRFToken": csf },
        mode: "same-origin", // Do not send CSRF token to another domain.
        beforeSend: function() {
            $(".preloader").css("visibility", "visible");
        },
        url: "/GetShift",
        type: "POST",
        data: data,
        success: function(data) {
            console.log(data)
            if (!data.err) {



                html = '<div class="leave">';
                html += '<div class="row mb-3">';
                html += '<label for="inputDate" class="col-sm-2 col-form-label">Your Shift</label>';
                html += '<div class="col-sm-10">';
                html += '<input disabled type="text" value="' + data.data + '" class="shift form-control">';
                html += '</div>';
                html += '</div>';



                html += '<div class="row mb-3">';
                html += '<label for="fullName" class="col-sm-2 col-form-label">Shift</label>';
                html += '<div class="col-sm-10">';
                html += '<select class="form-select shiftchanges">';
                html += ' <option selected disabled>Select Shift want to change</option>';
                html += ' <option value="8AM - 4PM">8AM - 4PM</option>';
                html += ' <option value="4PM - 12AM">4PM - 12AM</option>';
                html += ' <option value="12AM - 8AM">12AM - 8AM</option>';
                html += ' </select>';
                html += '<span id="shiftchanges_error"></span>';
                html += ' </div>';
                html += '</div>';


                html += '<div class="row mb-3">';
                html += '<label for="Reason" class="col-sm-2 col-form-label">Reason</label>';
                html += '<div class="col-sm-10">';
                html += '<textarea class="reason form-control"></textarea>';
                html += '<span id="reason_error"></span>';
                html += '</div>';
                html += '</div>';

                html += '<button type="button" class="btn btn-primary" onclick="ApplyShiftChange()">Submit</button>';
                html += '</div>';
                $('.shiftf').html(html);
            } else {
                html += '<span >' + data.data + '</span>';
                $('.shiftf').html(html);
            }

        },
        complete: function() {
            $(".preloader").css("visibility", "hidden");
        },
    });


}