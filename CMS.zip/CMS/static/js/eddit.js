function ChangeAdminPass() {
    // get values


    var cupass = $(".cupass").val();
    var pass = $(".pass").val();
    var pass1 = $(".pass1").val();


    if (cupass == "") {
        $("#cupass_error").html("Please Enter Your Current Password");
        check = "";
    } else {
        $("#cupass_error").html("");
        check = "ok";
    }

    if (pass == "") {
        $("#pass_error").html("Please  Enter Your New Password");
        check = "";
    } else {
        $("#pass_error").html("");
        check = "ok";
    }

    if (pass1 == "") {
        $("#pass1_error").html("Please re Enter Your New Password");
        check = "";
    } else {
        $("#pass1_error").html("");
        if (pass != pass1) {
            $("#pass1_error").html("Enter Password is not maching");
            check = "";
        } else {
            $("#pass1_error").html("");
            check = "ok";
        }
        check = "ok";
    }








    if (pass == pass1 &&
        pass1 != "" &&
        pass != "" &&
        cupass != ""
    ) {
        Swal.fire({
            title: "Are you sure Want to Change Your Password?",

            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "red",
            confirmButtonText: "Yes, Update it!",
        }).then((result) => {
            if (result.value) {


                let csf = $("input[name=csrfmiddlewaretoken]").val();


                var data = {
                    cupass,
                    pass,
                    pass1
                };
                $.ajax({
                    headers: { "X-CSRFToken": csf },
                    mode: "same-origin", // Do not send CSRF token to another domain.
                    beforeSend: function() {
                        $(".preloader").css("visibility", "visible");
                    },
                    url: "/ChangeAdminPass",
                    type: "POST",
                    data: data,
                    success: function(data) {
                        if (data.data == 111) {

                            Swal.fire({
                                position: "center",
                                icon: "success",
                                title: "UPDATED YOUR PASSWORD",
                                showConfirmButton: true,
                                timer: 3000,
                            });
                        } else if (data.data == 110) {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Current password is wrong!",
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Something went wrong!",
                            });
                        }

                    },
                    complete: function() {
                        $(".preloader").css("visibility", "hidden");
                    }
                });
            }
        });



    }

}








function UpdateStaff(id) {
    var name = $(".name").val().toUpperCase();
    var address = $(".address").val().toUpperCase();
    var ph_no = $(".ph_no").val();
    var gender = $(".gender").val();
    var dbs_no = $(".dbs_no").val();
    var nin_no = $(".nin_no").val();
    var staff_type = $(".staff_type").val();
    var dob = $(".dob").val();



    if (name == "") {
        $("#name_error").html(
            "**** !Please Enter The Sur Name ****"
        );
        $("#name_error").css("color", "red");
    } else {
        $("#name_error").html("");
        $("#name_error").css("color", "black");
    }





    if (gender == "" || gender == null) {
        $("#gender_error").html(
            "**** !Please Select the gender type****"
        );
        $("#gender_error").css("color", "red");
    } else {
        $("#gender_error").html("");
        $("#gender_error").css("color", "black");
    }

    if (ph_no == "") {
        $("#ph_no_error").html(
            "**** !Please Enter The  phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else if (
        isNaN(ph_no) == true ||
        ph_no == 0
    ) {
        $("#ph_no_error").html(
            "**** !Please Enter A Valid   phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else {
        $("#ph_no_error").html("");
        $("#ph_no_error").css("color", "black");
    }

    if (dob == "") {
        $("#dob_error").html(
            "**** !Please Enter The  DOB****"
        );
        $("#dob_error").css("color", "red");
    } else {
        $("#dob_error").html("");
        $("#dob_error").css("color", "black");
    }


    if (address == "") {
        $("#address_error").html(
            "**** !Please Enter The Staff address ****"
        );
        $("#address_error").css("color", "red");
    } else {
        $("#address_error").html("");
        $("#address_error").css("color", "black");
    }

    if (dbs_no == "") {
        $("#dbs_no_error").html(
            "**** !Please enter the DBS No****"
        );
        $("#dbs_no_error").css("color", "red");
    } else {
        $("#dbs_no_error").html("");
        $("#dbs_no_error").css("color", "black");
    }
    if (nin_no == "") {
        $("#nin_no_error").html(
            "**** !Please enter the NIN No****"
        );
        $("#nin_no_error").css("color", "red");
    } else {
        $("#nin_no_error").html("");
        $("#nin_no_error").css("color", "black");
    }

    if (staff_type == "" || staff_type == null) {
        $("#staff_type_error").html(
            "**** !Please Select Staf Type****"
        );
        $("#staff_type_error").css("color", "red");
    } else {
        $("#staff_type_error").html("");
        $("#staff_type_error").css("color", "black");
    }

    if (
        name != "" &&
        gender != "" &&
        dob !== "" &&
        address != "" &&
        ph_no !== "" &&
        nin_no != "" &&
        dbs_no != "" &&
        staff_type != ""
    ) {
        Swal.fire({
            title: "Are you sure Want to update?",

            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "red",
            confirmButtonText: "Yes, Update it!",
        }).then((result) => {
            if (result.value) {


                let csf = $("input[name=csrfmiddlewaretoken]").val();


                var data = {

                    name,
                    address,
                    ph_no,
                    gender,
                    dbs_no,
                    nin_no,
                    staff_type,
                    dob,
                    id
                };
                $.ajax({
                    headers: { "X-CSRFToken": csf },
                    mode: "same-origin", // Do not send CSRF token to another domain.
                    beforeSend: function() {
                        $(".preloader").css("visibility", "visible");
                    },
                    url: "/UpdateStaff",
                    type: "POST",
                    data: data,
                    success: function(data) {
                        StaffProfile(id);
                        if (data.data == 111) {
                            Swal.fire({
                                position: "center",
                                icon: "success",
                                title: "UPDATED THIS STAFF",
                                showConfirmButton: true,
                                timer: 3000,
                            });
                        } else if (data.data == 110) {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Duplicate data is Present!",
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Something went wrong!",
                            });
                        }


                    },
                    complete: function() {
                        $(".preloader").css("visibility", "hidden");
                    }
                });
            }
        });


    }
}










function Updateres(id) {
    var name = $(".name").val().toUpperCase();
    var address = $(".address").val().toUpperCase();
    var ph_no = $(".ph_no").val();
    var gender = $(".gender").val();
    var dob = $(".dob").val();
    var importent_to_me = $(".itm").val().toUpperCase();
    var like_to_talk = $(".ltta").val().toUpperCase();
    var things_that_upset = $(".ttum").val().toUpperCase();
    var communication = $(".comm").val().toUpperCase();
    var mobility = $(".mobi").val().toUpperCase();
    var like_in_me = $(".wplim").val().toUpperCase();
    var hobbies = $(".hobbi").val().toUpperCase();
    var important_people_and_place = $(".ipaip").val().toUpperCase();
    var childhood_memories = $(".cm").val().toUpperCase();
    var working_life = $(".mwl").val().toUpperCase();
    var medical_history = $(".mh").val().toUpperCase();




    if (name == "") {
        $("#name_error").html(
            "**** !Please Enter The Sur Name ****"
        );
        $("#name_error").css("color", "red");
    } else {
        $("#name_error").html("Full Name");
        $("#name_error").css("color", "black");
    }





    if (gender == "" || gender == null) {
        $("#gender_error").html(
            "**** !Please Select the gender type****"
        );
        $("#gender_error").css("color", "red");
    } else {
        $("#gender_error").html("Gender");
        $("#gender_error").css("color", "black");
    }

    if (ph_no == "") {
        $("#ph_no_error").html(
            "**** !Please Enter The  phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else if (
        isNaN(ph_no) == true ||
        ph_no == 0
    ) {
        $("#ph_no_error").html(
            "**** !Please Enter A Valid   phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else {
        $("#ph_no_error").html("Ph No");
        $("#ph_no_error").css("color", "black");
    }

    if (dob == "") {
        $("#dob_error").html(
            "**** !Please Enter The  DOB****"
        );
        $("#dob_error").css("color", "red");
    } else {
        $("#dob_error").html("DOB");
        $("#dob_error").css("color", "black");
    }


    if (address == "") {
        $("#address_error").html(
            "**** !Please Enter The Staff address ****"
        );
        $("#address_error").css("color", "red");
    } else {
        $("#address_error").html("Address");
        $("#address_error").css("color", "black");
    }


    if (
        name != "" &&
        gender != "" &&
        dob !== "" &&
        address != "" &&
        ph_no !== ""
    ) {
        Swal.fire({
            title: "Are you sure Want to update?",

            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "red",
            confirmButtonText: "Yes, Update it!",
        }).then((result) => {
            if (result.value) {


                let csf = $("input[name=csrfmiddlewaretoken]").val();


                var data = {

                    name,
                    address,
                    ph_no,
                    gender,
                    dob,
                    id,
                    importent_to_me,
                    like_to_talk,
                    things_that_upset,
                    communication,
                    mobility,
                    like_in_me,
                    hobbies,
                    important_people_and_place,
                    childhood_memories,
                    working_life,
                    medical_history
                };
                $.ajax({
                    headers: { "X-CSRFToken": csf },
                    mode: "same-origin", // Do not send CSRF token to another domain.
                    beforeSend: function() {
                        $(".preloader").css("visibility", "visible");
                    },
                    url: "/UpdateRes",
                    type: "POST",
                    data: data,
                    success: function(data) {
                        ResProfile(id);
                        if (data.data == 111) {
                            Swal.fire({
                                position: "center",
                                icon: "success",
                                title: "UPDATED THIS RESIDENT",
                                showConfirmButton: true,
                                timer: 3000,
                            });
                        } else if (data.data == 110) {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Duplicate data is Present!",
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Something went wrong!",
                            });
                        }


                    },
                    complete: function() {
                        $(".preloader").css("visibility", "hidden");
                    }
                });
            }
        });


    }
}