function AddNewStaff() {
    // var sur_name = $(".sur_name").val().toUpperCase();
    var name = $(".name").val().toUpperCase();
    var address = $(".address").val().toUpperCase();
    var ph_no = $(".ph_no").val();
    var email = $(".email").val();
    var gender = $(".gender").val();
    var dbs_no = $(".dbs_no").val();
    var nin_no = $(".nin_no").val();
    var staff_type = $(".staff_type").val();
    var dob = $(".dob").val();



    if (name == "") {
        $("#name_error").html(
            "**** !Please Enter The Sur Name ****"
        );
        $("#name_error").css("color", "red");
    } else {
        $("#name_error").html("Full Name");
        $("#name_error").css("color", "black");
    }



    if (email == "") {
        $("#email_error").html(
            "**** !Please Enter The E-mail  ****"
        );
        $("#email_error").css("color", "red");
    } else {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (regex.test(email)) {
            var emailval = "ok";
            $("#email_error").html("Your Email");
            $("#email_error").css("color", "black");
        } else {
            $("#email_error").html("**** !Please Enter A Valid  E-mail  ****");
            $("#email_error").css("color", "red");
        }
    }

    if (gender == "" || gender == null) {
        $("#gender_error").html(
            "**** !Please Select the gender type****"
        );
        $("#gender_error").css("color", "red");
    } else {
        $("#gender_error").html("Gender");
        $("#gender_error").css("color", "black");
    }

    if (ph_no == "") {
        $("#ph_no_error").html(
            "**** !Please Enter The  phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else if (

        isNaN(ph_no) == true ||
        ph_no == 0
    ) {
        $("#ph_no_error").html(
            "**** !Please Enter A Valid   phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else {
        $("#ph_no_error").html("Ph No");
        $("#ph_no_error").css("color", "black");
    }

    if (dob == "") {
        $("#dob_error").html(
            "**** !Please Enter The  DOB****"
        );
        $("#dob_error").css("color", "red");
    } else {
        $("#dob_error").html("DOB");
        $("#dob_error").css("color", "black");
    }


    if (address == "") {
        $("#address_error").html(
            "**** !Please Enter The Staff address ****"
        );
        $("#address_error").css("color", "red");
    } else {
        $("#address_error").html("Address");
        $("#address_error").css("color", "black");
    }

    if (dbs_no == "") {
        $("#dbs_no_error").html(
            "**** !Please enter the DBS No****"
        );
        $("#dbs_no_error").css("color", "red");
    } else {
        $("#dbs_no_error").html("");
        $("#dbs_no_error").css("color", "black");
    }
    if (nin_no == "") {
        $("#nin_no_error").html(
            "**** !Please enter the NIN No****"
        );
        $("#nin_no_error").css("color", "red");
    } else {
        $("#nin_no_error").html("NIN No");
        $("#nin_no_error").css("color", "black");
    }

    if (staff_type == "" || staff_type == null) {
        $("#staff_type_error").html(
            "**** !Please Select Staf Type****"
        );
        $("#staff_type_error").css("color", "red");
    } else {
        $("#staff_type_error").html("");
        $("#staff_type_error").css("color", "black");
    }









    if (
        name != "" &&
        address != "" &&
        ph_no != "" &&
        email != "" &&
        gender != "" &&

        dbs_no != "" &&
        nin_no != "" &&
        staff_type != "" &&

        dob != ""


    ) {

        let csf = $("input[name=csrfmiddlewaretoken]").val();


        var data = {
            // sur_name,
            name,
            address,
            ph_no,
            email,
            gender,

            dbs_no,
            nin_no,
            staff_type,

            dob
        };
        $.ajax({
            headers: { "X-CSRFToken": csf },
            mode: "same-origin", // Do not send CSRF token to another domain.
            beforeSend: function() {
                $(".preloader").css("visibility", "visible");
            },
            complete: function() {
                $(".preloader").css("visibility", "hidden");
            },
            url: "/AddNewStaff",
            type: "POST",
            data: data,
            success: function(data) {
                if (data.data == 111) {
                    GetAdminStaffs();
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "NEW STAFF IS ADDED",
                        showConfirmButton: true,
                    });
                } else if (data.data == 110) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Email Already Regestered",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong!",
                    });
                }


            },

        });

    }





}




function AddNewRes() {

    var name = $(".name").val().toUpperCase();
    var address = $(".address").val().toUpperCase();
    var ph_no = $(".ph_no").val();
    var email = $(".email").val();
    var gender = $(".gender").val();
    var dob = $(".dob").val();
    var importent_to_me = $(".itm").val().toUpperCase();
    var like_to_talk = $(".ltta").val().toUpperCase();
    var things_that_upset = $(".ttum").val().toUpperCase();
    var communication = $(".comm").val().toUpperCase();
    var mobility = $(".mobi").val().toUpperCase();
    var like_in_me = $(".wplim").val().toUpperCase();
    var hobbies = $(".hobbi").val().toUpperCase();
    var important_people_and_place = $(".ipaip").val().toUpperCase();
    var childhood_memories = $(".cm").val().toUpperCase();
    var working_life = $(".mwl").val().toUpperCase();
    var medical_history = $(".mh").val().toUpperCase();




    if (name == "") {
        $("#name_error").html(
            "**** !Please Enter The Sur Name ****"
        );
        $("#name_error").css("color", "red");
    } else {
        $("#name_error").html("Full Name");
        $("#name_error").css("color", "black");
    }



    if (email == "") {
        $("#email_error").html(
            "**** !Please Enter The E-mail  ****"
        );
        $("#email_error").css("color", "red");
    } else {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (regex.test(email)) {
            var emailval = "ok";
            $("#email_error").html("Your Email");
            $("#email_error").css("color", "black");
        } else {
            $("#email_error").html("**** !Please Enter A Valid  E-mail  ****");
            $("#email_error").css("color", "red");
        }
    }

    if (gender == "" || gender == null) {
        $("#gender_error").html(
            "**** !Please Select the gender type****"
        );
        $("#gender_error").css("color", "red");
    } else {
        $("#gender_error").html("Gender");
        $("#gender_error").css("color", "black");
    }

    if (ph_no == "") {
        $("#ph_no_error").html(
            "**** !Please Enter The  phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else if (
        isNaN(ph_no) == true ||
        ph_no == 0
    ) {
        $("#ph_no_error").html(
            "**** !Please Enter A Valid   phone Number  ****"
        );
        $("#ph_no_error").css("color", "red");
    } else {
        $("#ph_no_error").html("Ph No");
        $("#ph_no_error").css("color", "black");
    }

    if (dob == "") {
        $("#dob_error").html(
            "**** !Please Enter The  DOB****"
        );
        $("#dob_error").css("color", "red");
    } else {
        $("#dob_error").html("DOB");
        $("#dob_error").css("color", "black");
    }


    if (address == "") {
        $("#address_error").html(
            "**** !Please Enter The address ****"
        );
        $("#address_error").css("color", "red");
    } else {
        $("#address_error").html("Address");
        $("#address_error").css("color", "black");
    }


    if (

        name != "" &&
        address != "" &&
        name != "" &&
        address != "" &&
        ph_no != "" &&
        email != "" &&
        gender != "" &&
        dob != ""


    ) {

        let csf = $("input[name=csrfmiddlewaretoken]").val();


        var data = {
            name,
            address,
            ph_no,
            email,
            gender,
            // var dbs_no = $(".dbs_no").val();
            // var nin_no = $(".nin_no").val();
            dob,
            importent_to_me,
            like_to_talk,
            things_that_upset,
            communication,
            mobility,
            like_in_me,
            hobbies,
            important_people_and_place,
            childhood_memories,
            working_life,
            medical_history

        };
        $.ajax({
            headers: { "X-CSRFToken": csf },
            mode: "same-origin", // Do not send CSRF token to another domain.
            beforeSend: function() {
                $(".preloader").css("visibility", "visible");
            },
            url: "/AddNewRes",
            type: "POST",
            data: data,
            success: function(data) {
                if (data.data == 111) {
                    GetAdminRes();
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "NEW STAFF IS ADDED",
                        showConfirmButton: true,
                    });
                } else if (data.data == 110) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Duplicate Data Is Fount!",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong!",
                    });
                }


            },
            complete: function() {
                $(".preloader").css("visibility", "hidden");
            },
        });

    }





}



function AddActivity(activity, username, id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    Swal.fire({
        title: 'Note',
        input: 'textarea',
        inputAttributes: {
            autocapitalize: 'off'
        },
        showCancelButton: true,
        confirmButtonText: 'Done',
        showLoaderOnConfirm: true,
        preConfirm: (note) => {

            var data = {
                activity,
                username,
                id,
                note

            };
            $.ajax({
                headers: { "X-CSRFToken": csf },
                mode: "same-origin", // Do not send CSRF token to another domain.
                beforeSend: function() {
                    $(".preloader").css("visibility", "visible");
                },
                url: "/AddActivity",
                type: "POST",
                data: data,
                dataType: "json",
                success: function(data) {
                    if (data.data == 111) {
                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "NEW ACTIVITY IS ADDED",
                            showConfirmButton: true,
                        });
                    } else if (data.data == 110) {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Duplicate Data Is Fount!",
                        });
                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Something went wrong!",
                        });
                    }
                },
                complete: function() {
                    $(".preloader").css("visibility", "hidden");
                },
            });
        },
        allowOutsideClick: () => !Swal.isLoading()
    });



}





function UpdateShift(id) {


    var monday = $(".monday").val();
    var tuesday = $(".tuesday").val();
    var wednesday = $(".wednesday").val();
    var thursday = $(".thursday").val();
    var friday = $(".friday").val();
    var saturday = $(".saturday").val();
    var sunday = $(".sunday").val();
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    console.log(id)







    Swal.fire({
        title: "Do you want to update?",

        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "red",
        confirmButtonText: "Yes, Update!",
    }).then((result) => {
        if (result.value) {
            // Add record
            $.ajax({
                headers: { "X-CSRFToken": csf },
                mode: "same-origin", // Do not send CSRF token to another domain.
                beforeSend: function() {
                    $(".preloader").css("visibility", "visible");
                },
                url: '/UpdateShift',
                type: 'post',
                data: {
                    id,
                    monday,
                    thursday,
                    wednesday,
                    tuesday,
                    friday,
                    saturday,
                    sunday
                },
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    if (data.data == 111) {


                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "UPDATED SUCESSFULL",
                            showConfirmButton: true,
                        });
                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Something went wrong!",
                        });
                    }
                },
                complete: function() {
                    $(".preloader").css("visibility", "hidden");
                },


            });
        }
    });
}






function ApplyLeave() {

    var date = $(".date").val();
    var reason = $(".reason").val();
    var days = $(".days").val();



    if (days == "") {
        $("#days_error").html(
            "**** !Please Enter The  no of days  ****"
        );
        $("#days_error").css("color", "red");
    } else if (
        isNaN(days) == true ||
        days == 0 || days > 6
    ) {
        $("#days_error").html(
            "**** !No of days not be 0 or greater than 5****"
        );
        $("#days_error").css("color", "red");
    } else {
        $("#days_error").html("Ph No");

    }

    if (date == "") {
        $("#date_error").html(
            "**** !Please Select a Date****"
        );
        $("#date_error").css("color", "red");
    } else {
        $("#date_error").html("");

    }


    if (reason == "") {
        $("#reason_error").html(
            "**** !Please Enter The Reason ****"
        );
        $("#reason_error").css("color", "red");
    } else {
        $("#address_error").html("");

    }


    if (

        days != "" &&
        date != "" &&
        reason != "" &&
        isNaN(days) != true &&
        days != 0 &&
        days < 6





    ) {

        let csf = $("input[name=csrfmiddlewaretoken]").val();


        var data = {
            days,
            date,
            reason,

        };
        $.ajax({
            headers: { "X-CSRFToken": csf },
            mode: "same-origin", // Do not send CSRF token to another domain.
            beforeSend: function() {
                $(".preloader").css("visibility", "visible");
            },
            url: "/ApplyLeave",
            type: "POST",
            data: data,
            success: function(data) {
                if (data.data == 111) {
                    // GetAdminRes();
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "Application Submited",
                        showConfirmButton: true,
                    });
                } else if (data.data == 110) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Duplicate Data Is Fount!",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong!",
                    });
                }


            },
            complete: function() {
                $(".preloader").css("visibility", "hidden");
                window.location.replace("/LaS");
            },
        });

    }


}



function ApplyShiftChange() {

    var date = $(".date").val();
    var reason = $(".reason").val();
    var shift = $(".shift").val();
    var shiftchange = $(".shiftchanges").val();




    if (date == "") {
        $("#date_error").html(
            "**** !Please Select a Date****"
        );
        $("#date_error").css("color", "red");
    } else {
        $("#date_error").html("");

    }


    if (shiftchange == "" || shiftchange == null) {
        $("#shiftchanges_error").html(
            "**** !Please Enter The  Shift want to change****"
        );
        $("#shiftchanges_error").css("color", "red");
    } else if (shiftchange == shift) {

        $("#shiftchanges_error").html(
            "**** Please select another shift****"
        );
        $("#shiftchanges_error").css("color", "red");
    } else {
        $("#shiftchanges_error").html("");

    }





    if (reason == "") {
        $("#reason_error").html(
            "**** !Please Enter The Reason ****"
        );
        $("#reason_error").css("color", "red");
    } else {
        $("#address_error").html("");

    }


    if (

        shift != "" &&
        date != "" &&
        reason != "" &&
        shiftchange != "" &&
        shiftchange != shift






    ) {

        let csf = $("input[name=csrfmiddlewaretoken]").val();


        var data = {
            shift,
            date,
            reason,
            shiftchange

        };
        $.ajax({
            headers: { "X-CSRFToken": csf },
            mode: "same-origin", // Do not send CSRF token to another domain.
            beforeSend: function() {
                $(".preloader").css("visibility", "visible");
            },
            url: "/Shiftchange",
            type: "POST",
            data: data,
            success: function(data) {
                if (data.data == 111) {
                    // GetAdminRes();
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: "Application Submited",
                        showConfirmButton: true,
                    });
                } else if (data.data == 110) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Duplicate Data Is Fount!",
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Something went wrong!",
                    });
                }


            },
            complete: function() {
                $(".preloader").css("visibility", "hidden");

                window.location.replace("/LaS");
            },
        });

    }





}






function GrantPer(id, action) {


    let csf = $("input[name=csrfmiddlewaretoken]").val();








    Swal.fire({
        title: "Do you want to update?",

        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "red",
        confirmButtonText: "Yes, Update!",
    }).then((result) => {
        if (result.value) {
            // Add record
            $.ajax({
                headers: { "X-CSRFToken": csf },
                mode: "same-origin", // Do not send CSRF token to another domain.
                beforeSend: function() {
                    $(".preloader").css("visibility", "visible");
                },
                url: '/GrantPer',
                type: 'post',
                data: {
                    id,
                    action
                },
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    if (data.data == 111) {


                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "Permission Granted",
                            showConfirmButton: true,
                        });
                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Something went wrong!",
                        });
                    }
                },
                complete: function() {
                    $(".preloader").css("visibility", "hidden");
                    window.location.replace("/ShowNotifications");
                },


            });
        }
    });
}



function RejectPer(id, action) {


    let csf = $("input[name=csrfmiddlewaretoken]").val();








    Swal.fire({
        title: "Do you want to update?",

        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "red",
        confirmButtonText: "Yes, Update!",
    }).then((result) => {
        if (result.value) {
            // Add record
            $.ajax({
                headers: { "X-CSRFToken": csf },
                mode: "same-origin", // Do not send CSRF token to another domain.
                beforeSend: function() {
                    $(".preloader").css("visibility", "visible");
                },
                url: '/RejectPer',
                type: 'post',
                data: {
                    id,
                    action
                },
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    if (data.data == 111) {


                        Swal.fire({
                            position: "center",
                            icon: "success",
                            title: "Permission Granted",
                            showConfirmButton: true,
                        });
                    } else {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "Something went wrong!",
                        });
                    }
                },
                complete: function() {
                    $(".preloader").css("visibility", "hidden");
                    window.location.replace("/ShowNotifications");
                },


            });
        }
    });
}