function DeleteStaff(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    var data = {
        id
    };
    if (id != "") {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
        }).then((result) => {
            if (result.value) {

                $.ajax({
                    headers: { "X-CSRFToken": csf },
                    mode: "same-origin", // Do not send CSRF token to another domain.
                    beforeSend: function() {
                        $(".preloader").css("visibility", "visible");
                    },
                    url: "/DeleteStaff",
                    type: "POST",
                    data: data,
                    success: function(data) {

                        if (data.data == 111) {
                            Swal.fire("Deleted!", "Your file has been deleted.", "success");
                            GetAdminStaffs();
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Something went wrong!",
                            });
                        }

                    },
                    complete: function() {
                        $(".preloader").css("visibility", "hidden");
                    },
                });

            }
        });
    } else {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Something went wrong!",
        });
    }
}

function DeleteRes(id) {
    let csf = $("input[name=csrfmiddlewaretoken]").val();
    var data = {
        id
    };
    if (id != "") {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!",
        }).then((result) => {
            if (result.value) {

                $.ajax({
                    headers: { "X-CSRFToken": csf },
                    mode: "same-origin", // Do not send CSRF token to another domain.
                    beforeSend: function() {
                        $(".preloader").css("visibility", "visible");
                    },
                    url: "/DeleteRes",
                    type: "POST",
                    data: data,
                    success: function(data) {

                        if (data.data == 111) {
                            Swal.fire("Deleted!", "Your file has been deleted.", "success");
                            GetAdminRes();
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Something went wrong!",
                            });
                        }

                    },
                    complete: function() {
                        $(".preloader").css("visibility", "hidden");
                    },
                });

            }
        });
    } else {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Something went wrong!",
        });
    }
}




// function deletegallery(sl_no) {
//     if (sl_no != "") {
//         Swal.fire({
//             title: "Are you sure?",
//             text: "You won't be able to revert this!",
//             icon: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#3085d6",
//             cancelButtonColor: "#d33",
//             confirmButtonText: "Yes, delete it!",
//         }).then((result) => {
//             if (result.value) {
//                 $.post(
//                     "delete/deletegallery.php", {
//                         sl_no,
//                     },
//                     function(data, status) {
//                         // reload Users by using readRecords();

//                         if (data == 111) {
//                             Swal.fire("Deleted!", "Your file has been deleted.", "success");
//                             viewgallery();
//                         } else {
//                             Swal.fire({
//                                 icon: "error",
//                                 title: "Oops...",
//                                 text: "Something went wrong!",
//                             });
//                         }
//                     }
//                 );
//             }
//         });
//     } else {
//         Swal.fire({
//             icon: "error",
//             title: "Oops...",
//             text: "Something went wrong!",
//         });
//     }
// }






// function deletesub(sl_no) {
//     if (sl_no != "") {
//         Swal.fire({
//             title: "Are you sure?",
//             text: "You won't be able to revert this!",
//             icon: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#3085d6",
//             cancelButtonColor: "#d33",
//             confirmButtonText: "Yes, delete it!",
//         }).then((result) => {
//             if (result.value) {
//                 $.post(
//                     "delete/deletesubject.php", {
//                         sl_no,
//                     },
//                     function(data, status) {
//                         // reload Users by using readRecords();

//                         if (data == 111) {
//                             Swal.fire("Deleted!", "Your file has been deleted.", "success");
//                             viewsubject();
//                         } else {
//                             Swal.fire({
//                                 icon: "error",
//                                 title: "Oops...",
//                                 text: "Something went wrong!",
//                             });
//                         }
//                     }
//                 );
//             }
//         });
//     } else {
//         Swal.fire({
//             icon: "error",
//             title: "Oops...",
//             text: "Something went wrong!",
//         });
//     }
// }





// function deletequery(sl_no) {
//     if (sl_no != "") {
//         Swal.fire({
//             title: "Are you sure?",
//             text: "You won't be able to revert this!",
//             icon: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#3085d6",
//             cancelButtonColor: "#d33",
//             confirmButtonText: "Yes, delete it!",
//         }).then((result) => {
//             if (result.value) {
//                 $.post(
//                     "delete/deletequery.php", {
//                         sl_no,
//                     },
//                     function(data, status) {
//                         // reload Users by using readRecords();

//                         if (data == 111) {
//                             Swal.fire("Deleted!", "this query has been deleted.", "success");
//                             viewquery();
//                         } else {
//                             Swal.fire({
//                                 icon: "error",
//                                 title: "Oops...",
//                                 text: "Something went wrong!",
//                             });
//                         }
//                     }
//                 );
//             }
//         });
//     } else {
//         Swal.fire({
//             icon: "error",
//             title: "Oops...",
//             text: "Something went wrong!",
//         });
//     }
// }



// function deletestudent(add_no) {
//     if (add_no != "") {
//         Swal.fire({
//             title: "Are you sure?",
//             text: "You won't be able to revert this!",
//             icon: "warning",
//             showCancelButton: true,
//             confirmButtonColor: "#3085d6",
//             cancelButtonColor: "#d33",
//             confirmButtonText: "Yes, delete it!",
//         }).then((result) => {
//             if (result.value) {
//                 $.post(
//                     "delete/deletestudent.php", {
//                         add_no,
//                     },
//                     function(data, status) {
//                         // reload Users by using readRecords();
//                         console.log(data);

//                         if (data == 111) {
//                             Swal.fire("Deleted!", "Your file has been deleted.", "success");
//                             viewstudents()
//                         } else {
//                             Swal.fire({
//                                 icon: "error",
//                                 title: "Oops...",
//                                 text: "Something went wrong!",
//                             });
//                         }
//                     }
//                 );
//             }
//         });
//     } else {
//         Swal.fire({
//             icon: "error",
//             title: "Oops...",
//             text: "Something went wrong!",
//         });
//     }
// }