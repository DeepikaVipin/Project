function viewaddteacher() {
    console.log("hai");
    $.post("view/viewaddteacher.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};

function viewteacher() {
    console.log("hai");
    $.post("view/viewteacher.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};




function viewevents() {

    $.post("view/viewevents.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};


function viewslides() {

    $.post("view/viewslides.php", {


    }, function(data, status) {


        $(".data").html(data);


    });


};

function viewgallery() {

    $.post("view/viewgallery.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};


function viewsubject() {

    $.post("view/viewsubject.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};


function viewaddsubject() {

    $.post("view/viewaddsubject.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};




function viewquery() {

    $.post("view/viewquery.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};

function viewstudents() {

    $.post("view/viewstudent.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};

function viewaddstudent() {

    $.post("view/viewaddstudent.php", {

    }, function(data, status) {


        $(".data").html(data);


    });


};


function viewsprofile(sl_no) {

    $.post("view/viewstudentprofile.php", {
        sl_no

    }, function(data, status) {


        $(".data2").html(data);


    });


};




function viewselect(option) {
    // $(".dataa").html("");
    // $(".datab").html("");
    $(".datac").html("");
    if (option == 1) {
        $(".dataa").removeAttr('hidden');
        $(".datab").attr("hidden", true);

    } else if (option) {
        $(".datab").removeAttr('hidden');
        $(".dataa").attr("hidden", true);
    }
}

function viewmark(opt, add_no, sl_no) {
    $(".datac").html("");
    $.post("view/viewmark.php", {
        opt,
        add_no,
        sl_no

    }, function(data, status) {


        $(".datac").html(data);


    });


}

function viewatt(opt, add_no, sl_no) {
    $(".datac").html("");
    $.post("view/viewatt.php", {
        opt,
        add_no,
        sl_no

    }, function(data, status) {


        $(".datac").html(data);


    });


}


function viewddoc(path) {


    window.open("../files/sslcplus2/pdfreader.php?pdf=" + path, "_blank");
    // window.location.href = '../admin/cv/'+path;
};





function viewsfee(add_no, sl_no) {
    var $modal = $("#modal");

    $.post("view/viewmodaldata.php", {

        add_no,
        sl_no


    }, function(data, status) {


        $(".datamodal").html(data);
        $modal.modal("show");


    });


}

function changeamount() {
    var total = parseInt($("#total").html().replace('RS', ''));
    var payed = parseInt($("#payed").html().replace('RS', ''));

    var amount = $("#amount").val();

    var balence = (total - payed) - amount;
    $("#balence").html(balence + " RS");
}